Noor Baby (نور بيبي) Android App – Implementation Blueprint

Overview
This document describes how to build the Noor Baby app for Android. It includes:
- Project setup and dependencies
- Asset sourcing and organization
- UI architecture and interaction logic for piano, flute (nay), guitar, and animal-/baby-sound grid
- Immersive full-screen (kiosk) mode and notification/call blocking
- Custom exit mechanism via rotating wheel control
- Building and generating a signed APK
... (see details in previous chat)
