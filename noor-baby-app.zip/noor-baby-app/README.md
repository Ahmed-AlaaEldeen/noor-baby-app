
# Noor Baby Android Project

هذا مجلد مشروع تطبيق "Noor Baby" الأساسي. لتفعيله على GitHub:
1. أنشئ مستودعاً جديداً باسم `noor-baby-app`.
2. يُرفع محتوى هذا المجلد عبر تحويله إلى ZIP ورفعه عبر واجهة GitHub (على هاتفك).
3. GitHub Actions سيتعرف على الملف `.github/workflows/android.yml` ويبني APK تلقائياً.
4. بعد نجاح البناء، ستجد ملف الـAPK في صفحة Releases.

